<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Public Domain',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bf6b7c1757cc58a620beabbfe6c14b76',
      'native_key' => 'ultimateparent',
      'filename' => 'modNamespace/baf5c274c681a8eade0cd526f9083f98.vehicle',
      'namespace' => 'ultimateparent',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '441bce942a3f442daf28c6ebe4aa6ad6',
      'native_key' => 1,
      'filename' => 'modSnippet/fa229a175f12094afa975cc8dbd8e1b8.vehicle',
      'namespace' => 'ultimateparent',
    ),
  ),
);