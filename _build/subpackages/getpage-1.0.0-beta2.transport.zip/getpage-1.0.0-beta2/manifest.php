<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '7ebc0beaea771d3789e7a38b7c085789',
      'native_key' => NULL,
      'filename' => 'modSnippet/cfaa40c064ca539137a3bcdfbb021215.vehicle',
    ),
  ),
);