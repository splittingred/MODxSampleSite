--------------------
Snippet: tagLister
--------------------
Version: 1.0.0
Created: June 14th, 2010
Author: Shaun McCormick <shaun@modxcms.com>
License: GNU GPLv2 (or later at your option)

A simple tag listing snippet that grabs tags from a TV value.

Please see the documentation at:
http://docs.modxcms.com/display/ADDON/tagLister/

Thanks for using tagLister!
Shaun McCormick
shaun@modxcms.com