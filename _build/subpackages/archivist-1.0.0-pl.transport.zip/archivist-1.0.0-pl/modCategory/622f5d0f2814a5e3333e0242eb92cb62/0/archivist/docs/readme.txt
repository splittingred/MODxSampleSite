--------------------
Snippet: Archivist
--------------------
Version: 1.0.0
Created: June 3rd, 2010
Updated: June 14th, 2010
Author: Shaun McCormick <shaun@modxcms.com>
License: GNU GPLv2 (or later at your option)

This is a simple archiving component. Please see the documentation at:
http://docs.modxcms.com/display/ADDON/Archivist/

Updates in 1.0.0-rc-2:
- Fixed bug where locale was being ignored


Thanks for using Archivist!
Shaun McCormick
shaun@modxcms.com