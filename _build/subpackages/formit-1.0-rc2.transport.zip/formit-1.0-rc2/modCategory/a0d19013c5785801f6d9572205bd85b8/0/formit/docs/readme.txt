--------------------
Snippet: FormIt
--------------------
Version: 1.0
Since: June 25, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A form processing Snippet for MODx Revolution.

Official Documentation:
http://svn.modxcms.com/docs/display/ADDON/FormIt