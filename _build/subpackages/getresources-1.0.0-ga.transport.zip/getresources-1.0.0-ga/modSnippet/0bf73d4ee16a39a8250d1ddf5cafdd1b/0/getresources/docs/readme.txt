--------------------
Snippet: getResources
--------------------
Version: 1.0.0-ga
Since: December 28, 2009
Author: Jason Coward <modx@opengeek.com>

A general purpose Resource listing and summarization snippet for MODx Revolution.

Official Documentation:
http://svn.modxcms.com/docs/display/ADDON/getResources