--------------------
Snippet: SimpleSearch
--------------------
Version: 1.0
Since: June 2nd, 2010
Author: Shaun McCormick <shaun@modxcms.com>
License: GNU GPLv2 (or later at your option)

This is a simple search component. Please see the documentation at:
http://docs.modxcms.com/display/ADDON/SimpleSearch/

Thanks for using SimpleSearch!
Shaun McCormick
shaun@modxcms.com