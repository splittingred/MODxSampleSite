<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Public Domain',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd4ba972f79d21639aef20726575c8f49',
      'native_key' => 'ultimateparent',
      'filename' => 'modNamespace/82625f99a7986cf51e3c5fad19926177.vehicle',
      'namespace' => 'ultimateparent',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '1ea88a18622d066d8d181cee7cfb08c2',
      'native_key' => 1,
      'filename' => 'modSnippet/587fb4c6e2934f66ec10d2888fdca781.vehicle',
      'namespace' => 'ultimateparent',
    ),
  ),
);