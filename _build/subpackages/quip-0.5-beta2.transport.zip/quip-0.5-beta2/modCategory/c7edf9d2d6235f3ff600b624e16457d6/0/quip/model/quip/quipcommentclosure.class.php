<?php
/**
 * @package quip
 */
class quipCommentClosure extends xPDOObject {}
?>