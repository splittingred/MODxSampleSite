<?php
/**
 * @package quip
 */
class quipCommentNotify extends xPDOSimpleObject {}
?>