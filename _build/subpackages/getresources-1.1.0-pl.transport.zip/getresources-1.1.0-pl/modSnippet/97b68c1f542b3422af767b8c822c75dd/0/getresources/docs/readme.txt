--------------------
Snippet: getResources
--------------------
Version: 1.1.0-pl
Released: July 30, 2010
Since: December 28, 2009
Author: Jason Coward <jason@modx.com>

A general purpose Resource listing and summarization snippet for MODx Revolution.

Official Documentation:
http://docs.modxcms.com/display/ADDON/getResources
